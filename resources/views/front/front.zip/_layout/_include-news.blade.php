@if(count($news) >= 1)
	<div id="news" class="animatedParent animateOnce">
		<div class="wrapper">
			<h1 class="animated bounceInLeft slower delay-250">News</h1>

			<div id="bar-wrapper" class="text-center animated bounceInRight slower delay-250">
				@include('front._layout._include-news-list')
			</div>
		</div>
	</div>
@endif